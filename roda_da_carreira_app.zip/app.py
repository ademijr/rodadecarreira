
import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from pathlib import Path
from career_analysis import *

# Configuração da página
st.set_page_config(
    page_title="Roda da Carreira - Análise Profissional",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Estilo CSS personalizado
st.markdown("""
    <style>
    .main {
        padding: 2rem;
    }
    .stButton>button {
        width: 100%;
        margin-top: 1rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
    }
    </style>
    """, unsafe_allow_html=True)

# Sidebar com informações do usuário
with st.sidebar:
    st.title("🎯 Perfil Profissional")

    # Informações pessoais
    st.subheader("Dados Profissionais")
    nome = st.text_input("Nome completo")
    email = st.text_input("E-mail profissional")

    # Informações de cargo
    st.subheader("Informações de Cargo")
    cargo_atual = st.text_input("Cargo Atual")
    cargo_desejado = st.text_input("Cargo Desejado")

    # Experiência
    anos_experiencia = st.slider("Anos de Experiência", 0, 30, 5)

    # Setor de atuação
    setor = st.selectbox("Setor de Atuação", [
        "Tecnologia",
        "Finanças",
        "Saúde",
        "Educação",
        "Varejo",
        "Indústria",
        "Serviços",
        "Outro"
    ])

# Conteúdo principal
st.title("🎯 Roda da Carreira - Análise Profissional")

# Tabs para organizar o conteúdo
tab1, tab2, tab3 = st.tabs(["📊 Avaliação", "📈 Análise", "📋 Plano de Desenvolvimento"])

with tab1:
    st.markdown("""
    ### Avalie sua situação atual e objetivos
    Para cada dimensão, avalie sua situação atual e onde você deseja chegar em uma escala de 0 a 10.
    """)

    # Dimensões da carreira
    dimensoes = [
        'Desenvolvimento Profissional / Aprendizado',
        'Satisfação / Felicidade no Trabalho',
        'Equilíbrio Vida Pessoal e Trabalho',
        'Reconhecimento',
        'Recompensa (salário + benefícios)',
        'Perspectiva de Crescimento de Carreira',
        'Relacionamentos Profissionais',
        'Autonomia e Controle',
        'Alinhamento com Propósito Pessoal'
    ]

    # Dicionário para armazenar os valores
    if 'valores' not in st.session_state:
        st.session_state.valores = {
            'atual': {dim: 5 for dim in dimensoes},
            'desejado': {dim: 8 for dim in dimensoes}
        }

    # Criar avaliação para cada dimensão
    for dim in dimensoes:
        st.markdown(f"#### {dim}")
        col1, col2 = st.columns(2)

        with col1:
            st.markdown("**Estado Atual**")
            st.session_state.valores['atual'][dim] = st.slider(
                f"Atual - {dim}",
                0, 10, 
                st.session_state.valores['atual'][dim],
                key=f"atual_{dim}",
                help=f"Avalie sua situação atual em {dim}"
            )

        with col2:
            st.markdown("**Estado Desejado**")
            st.session_state.valores['desejado'][dim] = st.slider(
                f"Desejado - {dim}",
                0, 10,
                st.session_state.valores['desejado'][dim],
                key=f"desejado_{dim}",
                help=f"Defina seu objetivo para {dim}"
            )

        # Mostrar descrição dos níveis
        with st.expander(f"📖 Guia de Avaliação - {dim}"):
            st.markdown("""
            - **0-2**: Nível crítico/insatisfatório
            - **3-4**: Nível baixo/necessita melhorias significativas
            - **5-6**: Nível médio/adequado com espaço para melhorias
            - **7-8**: Nível bom/satisfatório
            - **9-10**: Nível excelente/excepcional
            """)
        st.markdown("---")

with tab2:
    if st.button("Gerar Análise", key="gerar_analise"):
        # Criar gráfico radar com Plotly
        fig = go.Figure()

        # Adicionar o primeiro valor novamente para fechar o polígono
        dimensoes_plot = dimensoes + [dimensoes[0]]
        valores_atual = [st.session_state.valores['atual'][dim] for dim in dimensoes] + [st.session_state.valores['atual'][dimensoes[0]]]
        valores_desejado = [st.session_state.valores['desejado'][dim] for dim in dimensoes] + [st.session_state.valores['desejado'][dimensoes[0]]]

        # Adicionar traces
        fig.add_trace(go.Scatterpolar(
            r=valores_atual,
            theta=dimensoes_plot,
            fill='toself',
            name='Estado Atual',
            line_color='#FF6B6B'
        ))

        fig.add_trace(go.Scatterpolar(
            r=valores_desejado,
            theta=dimensoes_plot,
            fill='toself',
            name='Estado Desejado',
            line_color='#4ECDC4'
        ))

        # Atualizar layout
        fig.update_layout(
            polar=dict(
                radialaxis=dict(
                    visible=True,
                    range=[0, 10]
                )
            ),
            showlegend=True,
            title="Análise da Roda da Carreira"
        )

        # Mostrar o gráfico
        st.plotly_chart(fig, use_container_width=True)

        # Análise dos gaps
        st.markdown("### Análise Detalhada")

        gaps = {dim: st.session_state.valores['desejado'][dim] - st.session_state.valores['atual'][dim] for dim in dimensoes}
        maiores_gaps = sorted(gaps.items(), key=lambda x: x[1], reverse=True)

        # Mostrar resumo dos principais gaps
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Maior Gap", f"{maiores_gaps[0][0]}: {maiores_gaps[0][1]}")
        with col2:
            st.metric("Gap Médio", f"{sum(gaps.values())/len(gaps):.1f}")
        with col3:
            st.metric("Dimensões Críticas", len([g for g in gaps.values() if g > 3]))

        # Análise detalhada por dimensão
        for dim, gap in maiores_gaps:
            if gap > 0:
                with st.expander(f"📊 {dim} (Gap: {gap})"):
                    atual = st.session_state.valores['atual'][dim]
                    desejado = st.session_state.valores['desejado'][dim]

                    col1, col2 = st.columns(2)
                    with col1:
                        st.markdown("**Situação Atual**")
                        st.markdown(get_situacao_atual(dim, atual))
                    with col2:
                        st.markdown("**Objetivo**")
                        st.markdown(get_objetivo(dim, desejado))

                    st.markdown("**Análise do Gap**")
                    st.markdown(get_analise_gap(dim, gap))

with tab3:
    if st.button("Gerar Plano de Desenvolvimento", key="gerar_plano"):
        st.markdown("### 📋 Plano de Desenvolvimento Personalizado")

        # Filtrar dimensões com gaps significativos
        gaps_significativos = [(dim, gap) for dim, gap in gaps.items() if gap > 2]

        for dim, gap in gaps_significativos:
            with st.expander(f"🎯 Plano para {dim}"):
                atual = st.session_state.valores['atual'][dim]
                desejado = st.session_state.valores['desejado'][dim]

                st.markdown("#### Ações Imediatas (30 dias)")
                st.markdown(get_acoes_imediatas(dim, atual, desejado))

                st.markdown("#### Ações de Médio Prazo (90 dias)")
                st.markdown(get_acoes_medio_prazo(dim, atual, desejado))

                st.markdown("#### Ações de Longo Prazo (180 dias)")
                st.markdown(get_acoes_longo_prazo(dim, atual, desejado))

                col1, col2 = st.columns(2)
                with col1:
                    st.markdown("#### Métricas de Sucesso")
                    st.markdown(get_metricas_sucesso(dim))
                with col2:
                    st.markdown("#### Recursos Recomendados")
                    st.markdown(get_recursos_recomendados(dim))

        # Botão para exportar o plano
        if st.button("📥 Exportar Plano de Desenvolvimento"):
            # Criar DataFrame com os dados
            dados = {
                'Dimensão': dimensoes,
                'Estado Atual': [st.session_state.valores['atual'][dim] for dim in dimensoes],
                'Estado Desejado': [st.session_state.valores['desejado'][dim] for dim in dimensoes],
                'Gap': [gaps[dim] for dim in dimensoes]
            }
            df = pd.DataFrame(dados)

            # Salvar como CSV
            df.to_csv('plano_desenvolvimento.csv', index=False)
            st.success("Plano exportado com sucesso!")

# Adicionar informações de ajuda
with st.expander("📖 Como usar esta ferramenta"):
    st.markdown("""
    ### Guia de Uso

    1. **Preencha seu perfil**
       - Complete as informações na barra lateral
       - Seja específico sobre seu cargo atual e desejado

    2. **Faça sua avaliação**
       - Avalie cada dimensão na aba 'Avaliação'
       - Use o guia de níveis para referência
       - Seja honesto em suas avaliações

    3. **Analise os resultados**
       - Gere o gráfico na aba 'Análise'
       - Identifique os principais gaps
       - Entenda as áreas prioritárias

    4. **Desenvolva seu plano**
       - Use o plano de desenvolvimento personalizado
       - Foque nas ações práticas sugeridas
       - Acompanhe seu progresso regularmente

    ### Dicas importantes:
    - Reavalie periodicamente (a cada 3-6 meses)
    - Mantenha o foco nas dimensões prioritárias
    - Use as métricas sugeridas para acompanhamento
    - Aproveite os recursos recomendados
    """)
